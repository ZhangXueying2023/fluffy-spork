# -*-coding: UTF-8 -*-
from tkinter import *
from tkinter.messagebox import showinfo
from main import main
from tkinter import *
from tkinter import ttk
from tkinter.messagebox import showinfo, showerror
import pymysql

#界面
class Login(object):
    idnum =' '
    model=0
    def __init__(self, master):
        self.root = master  # 定义内部变量root
        self.root.geometry('300x180')  # 设置窗口大小


        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()

        Button(self.Win, text='个人登录/注册', command=self.workerpage).grid(row=1, stick=W, pady=10)
        Button(self.Win, text='企业登录/注册', command=self.companypage).grid(row=2, stick=W,  pady=10)
        Button(self.Win, text='退出', command=self.Win.quit).grid(row=3, pady=10, stick=W)

    def workerpage(self):
        self.Win.destroy()
        Worker(self.root)

    def companypage(self):
        self.Win.destroy()
        Company(self.root)

#个人模式
class Worker(object):
    idnum=' '
    def __init__(self, master):
        Login.model=1
        self.root = master  # 定义内部变量root
        self.root.geometry('300x180')  # 设置窗口大小

        self.username = StringVar()
        self.password = StringVar()
        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        Label(self.Win).grid(row=0, stick=W)
        Label(self.Win, text='身份证号: ').grid(row=1, stick=W, pady=10)
        Entry(self.Win, textvariable=self.username).grid(row=1, column=1, stick=E)
        Label(self.Win, text='密码: ').grid(row=2, stick=W, pady=10)
        Entry(self.Win, textvariable=self.password, show='*').grid(row=2, column=1, stick=E)
        Button(self.Win, text='登陆', command=self.loginCheck).grid(row=3, stick=W, pady=10)
        Button(self.Win, text='注册', command=self.signUp).grid(row=3, stick=W,  column=1)
        Button(self.Win, text='返回', command=self.goback).grid(row=3, column=1, stick=E)

    def loginCheck(self):
        Worker.idnum=self.username.get()
        if len(Worker.idnum)!=18:
            showinfo(title='错误', message='身份证号为18位！')
        else:
            password = self.password.get()
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql='select passwd from worker where id = %s'
            cur.execute(sql,Worker.idnum)
            result=cur.fetchone()
            if result==None:
                showinfo(title='错误', message='账号错误！')
            elif  password == str(result[0]):
                self.Win.destroy()
                Home(self.root)
            else:
                print("123")
                print(result[0])
                showinfo(title='错误', message='密码错误！')
            cur.close()
            con.close()

    def signUp(self):
        self.Win.destroy()
        Sign(self.root)

    def goback(self):
        self.Win.destroy()
        Login(self.root)
#注册
class Sign(object):
    def __init__(self, master):
        self.root = master  # 定义内部变量root
        self.root.geometry('300x300')  # 设置窗口大小

        self.username = StringVar()
        self.password = StringVar()
        self.name = StringVar()
        self.mail = StringVar()
        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        Label(self.Win).grid(row=0, stick=W)
        if Login.model==1:
            Label(self.Win, text='身份证号: ').grid(row=1, stick=W, pady=10)
        elif Login.model==2:
            Label(self.Win, text='企业注册号: ').grid(row=1, stick=W, pady=10)
        Entry(self.Win, textvariable=self.username).grid(row=1, column=1, stick=E)
        if Login.model==1:
            Label(self.Win, text='姓名: ').grid(row=2, stick=W, pady=10)
        elif Login.model==2:
            Label(self.Win, text='企业名称: ').grid(row=2, stick=W, pady=10)

        Entry(self.Win, textvariable=self.name).grid(row=2, column=1, stick=E)
        Label(self.Win, text='邮箱: ').grid(row=3, stick=W, pady=10)
        Entry(self.Win, textvariable=self.mail).grid(row=3, column=1, stick=E)
        Label(self.Win, text='密码: ').grid(row=4, stick=W, pady=10)
        Entry(self.Win, textvariable=self.password, show='*').grid(row=4, column=1, stick=E)

        Button(self.Win, text='注册', command=self.insert_user).grid(row=5, stick=W,  pady=10)
        Button(self.Win, text='返回', command=self.closepage).grid(row=5, column=1, stick=E)

    def insert_user(self):
        id = self.username.get()
        passwd = self.password.get()
        name =self.name.get()
        mail=self.mail.get()
        if Login.model==1:
            if len(id)!=18:
                showinfo(title='提示', message='身份证号为18位！')
            else:
                con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
                cur = con.cursor()
                sql = 'select * from `worker` where id=%s;'
                cur.execute(sql, id)
                result = cur.fetchone()
                cur.close()
                con.close()
                if result!=None:
                    showinfo(title='提示', message='身份证号已注册！')
                elif len(passwd)==0:
                    showinfo(title='提示', message='密码不能为空!')
                elif len(name)==0:
                    showinfo(title='提示', message='请填写姓名！')
                elif len(mail)==0:
                    showinfo(title='提示', message='请填写邮箱！')
                else:
                    con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
                    cur = con.cursor()
                    sql='insert into `worker` (`id`,`name`,`passwd`,`email`) values (%s,%s,%s,%s);'
                    cur.execute(sql,(id,name,passwd,mail))
                    con.commit()
                    showinfo(title='提示', message='注册成功，请登录完善信息！')

                    cur.close()
                    con.close()
                    self.Win.destroy()
                    Login(self.root)


        elif Login.model == 2:
            if len(id) != 10:
                showinfo(title='提示', message='企业注册号为10位！')
            else:
                con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
                cur = con.cursor()
                sql = 'select * from `company` where cid=%s;'
                cur.execute(sql, id)
                result = cur.fetchone()
                cur.close()
                con.close()
                if result!=None:
                    showinfo(title='提示', message='企业号已注册！')
                elif len(passwd) == 0:
                    showinfo(title='提示', message='密码不能为空!')
                elif len(name) == 0:
                    showinfo(title='提示', message='请填写企业名称！')
                elif len(mail) == 0:
                    showinfo(title='提示', message='请填写邮箱！')
                else:
                    con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
                    cur = con.cursor()
                    sql = 'insert into `company` (`cid`,`name`,`passwd`,`email`) values (%s,%s,%s,%s);'
                    cur.execute(sql, (id, name, passwd, mail))
                    con.commit()
                    showinfo(title='提示', message='注册成功，请登录完善信息！')
                    cur.close()
                    con.close()
                    self.Win.destroy()
                    Login(self.root)

    def closepage(self):
        self.Win.destroy()
        Login(self.root)

#密码设置
class Password(object):

    def __init__(self, master):
        self.root = master  # 定义内部变量root
        self.root.geometry('300x200')  # 设置窗口大小

        self.username=StringVar()
        self.passwd=StringVar()
        self.newpasswd=StringVar()
        self.repasswd=StringVar()
        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        Label(self.Win).grid(row=0, stick=W)
        Label(self.Win, text='原密码: ').grid(row=1, stick=W, pady=10)
        Entry(self.Win, textvariable=self.passwd,show='*').grid(row=1, column=1, stick=E)
        Label(self.Win, text='新密码: ').grid(row=2, stick=W, pady=10)
        Entry(self.Win, textvariable=self.newpasswd,show='*').grid(row=2, column=1, stick=E)
        Label(self.Win, text='确认新密码: ').grid(row=3, stick=W, pady=10)
        Entry(self.Win, textvariable=self.repasswd,show='*').grid(row=3, column=1, stick=E)
        Button(self.Win, text='确认', command=self.Commitpass).grid(row=4, stick=W,  pady=10)
        Button(self.Win, text='返回', command=self.goback).grid(row=4, column=1, stick=W)

    def Commitpass(self):
        passwd=self.passwd.get()
        newpasswd=self.newpasswd.get()
        repasswd=self.repasswd.get()
        if len(passwd)==0 :
            showinfo(title='提示', message='请输入原密码！')
        elif len(newpasswd)==0:
            showinfo(title='提示', message='请输入新密码！')
        elif len(repasswd)==0:
            showinfo(title='提示', message='请再次输入原密码！')
        elif newpasswd!=repasswd:
            showinfo(title='提示', message='新密码两次输入不相同！')
        else:
            if Login.model==1:
                con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
                cur = con.cursor()

                sql = 'select passwd from worker where id = %s'
                cur.execute(sql, Worker.idnum)
                result = cur.fetchone()
                if passwd!=result[0]:
                    showinfo(title='提示', message='原密码错误！')
                else:
                    sql = 'update worker set passwd=%s where id = %s'
                    cur.execute(sql, (newpasswd,Worker.idnum))
                    con.commit()
                    showinfo(title='提示', message='密码修改成功！')
                cur.close()
                con.close()
            elif Login.model==2:
                con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
                cur = con.cursor()

                sql = 'select passwd from company where cid = %s'
                cur.execute(sql, Company.idnum)
                result = cur.fetchone()
                if passwd!=result[0]:
                    showinfo(title='提示', message='原密码错误！')
                else:
                    sql = 'update company set passwd=%s where cid = %s'
                    cur.execute(sql, (newpasswd,Company.idnum))
                    con.commit()
                    showinfo(title='提示', message='密码修改成功！')
                cur.close()
                con.close()

    def goback(self):
        self.Win.destroy()
        if Login.model==1:
            Home(self.root)
        elif Login.model==2:
            CompanyHome(self.root)

#个人首页
class Home(object):
    def __init__(self, master):
        self.root = master  # 定义内部变量root
        self.root.geometry('300x300')  # 设置窗口大小

        self.username = Worker.idnum

        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        Label(self.Win).grid(row=0, stick=W)
        Label(self.Win, text="身份证号："+self.username).grid(row=1, stick=W, pady=10)

        Button(self.Win, text='个人信息', command=self.information).grid(row=2, stick=S,  pady=10)
        Button(self.Win, text='查询职位', command=self.search).grid(row=3, stick=S, pady=10)
        Button(self.Win, text='密码设置', command=self.passwd).grid(row=4, stick=S, pady=10)
        Button(self.Win, text='退出登录', command=self.logout).grid(row=5, stick=S, pady=10)


    def information(self):
        self.Win.destroy()
        Infor(self.root)

    def search(self):
        self.Win.destroy()
        Job(self.root)

    def passwd(self):
        self.Win.destroy()
        Password(self.root)

    def logout(self):

        self.Win.destroy()
        Login(self.root)

#个人信息
class Infor(object):
    def __init__(self, master):
        self.root = master  # 定义内部变量root
        self.root.geometry('600x300')  # 设置窗口大小

        self.username = Worker.idnum
        self.sex = StringVar()
        self.mail = StringVar()
        self.university = StringVar()
        self.major = StringVar()
        self.degree = StringVar()
        print(int(Worker.idnum)//10)
        if ((int(Worker.idnum)//10))%2==0:
            self.sex = '女'
        else:
            self.sex = '男'

        self.name=StringVar()
        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
        cur = con.cursor()
        sql = 'select name,email,university,major,degree from worker where id = %s'
        cur.execute(sql, Worker.idnum)
        result = cur.fetchone()
        cur.close()
        con.close()
        Label(self.Win).grid(row=0, stick=W)
        Label(self.Win, text="身份证号：").grid(row=1, stick=E, pady=10)
        Label(self.Win, text=self.username).grid(row=1, stick=W, column=1)
        Label(self.Win, text="姓名：").grid(row=1, stick=E, column=2)
        Label(self.Win, text=result[0]).grid(row=1, stick=W, column=3)
        Label(self.Win, text='性别: ').grid(row=1, stick=E, column=4)
        Label(self.Win, text=self.sex).grid(row=1, stick=W, column=5)
        Label(self.Win, text='毕业院校: ').grid(row=2, stick=E, pady=10)
        Entry(self.Win, textvariable=self.university).grid(row=2, stick=W, column=1)
        Label(self.Win, text='专业: ').grid(row=2, stick=E, column=2)
        Entry(self.Win, textvariable=self.major).grid(row=2, stick=W, column=3)
        Label(self.Win, text='学位: ').grid(row=2, stick=E, column=4)
        Entry(self.Win, textvariable=self.degree).grid(row=2, stick=W, column=5)
        Label(self.Win, text='邮箱: ').grid(row=3, stick=E, pady=10)
        Entry(self.Win, textvariable=self.mail).grid(row=3, stick=W, column=1)
        self.mail.set(result[1])
        self.university.set(result[2])
        self.major.set(result[3])
        self.degree.set(result[4])
        Button(self.Win, text='保存编辑', command=self.inforedit).grid(row=3, stick=E,  column=3)
        Button(self.Win, text='返回', command=self.goback).grid(row=3, stick=E,column=5)


    def inforedit(self):
        mail=self.mail.get()
        university= self.university.get()
        major = self.major.get()
        degree=self.degree.get()
        if len(mail)==0:
            showinfo(title='提示', message='邮箱不能为空！')
        else:
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql = 'update worker set email=%s,university=%s,major=%s,degree=%s where id=%s'
            cur.execute(sql, (mail,university,major,degree,Worker.idnum))
            con.commit()
            self.Win.destroy()
            Infor(self.root)
    def goback(self):

        self.Win.destroy()
        Home(self.root)

#查询工作
class Job(object):
    def __init__(self, master):
        self.root = master
        self.root.geometry('600x500')  # 设置窗口大小

        self.cid = StringVar()
        self.cname = StringVar()
        self.position = StringVar()
        self.education = StringVar()

        self.createWindow()

    def createWindow(self):
        # self.Win = Frame(self.Win)
        # self.Win = tk.Tk(className="图书管理系统")
        # self.Win.pack()
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()

        Label(self.Win).grid(row=0, stick=W)

        Label(self.Win, text="企业注册号：").grid(row=1, stick=E, pady=10)
        Label(self.Win, text="企业名称：").grid(row=1, stick=E, column=2)
        Label(self.Win, text="职位：").grid(row=2, stick=E, pady=10)
        Label(self.Win, text="学历要求：").grid(row=2, stick=E, column=2)

        Entry(self.Win, textvariable=self.cid).grid(row=1, stick=W, column=1)
        Entry(self.Win, textvariable=self.cname).grid(row=1, stick=W, column=3)
        Entry(self.Win, textvariable=self.position).grid(row=2, stick=W, column=1)
        Entry(self.Win, textvariable=self.education).grid(row=2, stick=W, column=3)
        # 按钮
        Button(self.Win, text="查询岗位", command=self.selectJob).grid(row=3, stick=W, pady=10)
        Button(self.Win, text="申请岗位", command=self.apply).grid(row=3,stick=W, column=1)
        Button(self.Win, text="显示所有岗位", command=self.showAll).grid(row=3, stick=W, column=2)
        Button(self.Win, text="返回", command=self.goback).grid(row=3, stick=E, column=3)

        # 表格
        Job.diag1 = ttk.Treeview(self.Win, show='headings', column=('cid'))
        Job.diag2 = ttk.Treeview(self.Win, show='headings',column=( 'cname','position'))
        Job.diag3 = ttk.Treeview(self.Win, show='headings', column=('education'))
        Job.diag4 = ttk.Treeview(self.Win, show='headings', column=('remain', 'describe'))
        Job.diag1.column('cid', width=100, anchor="center")
        Job.diag2.column('cname', width=100, anchor="center")
        Job.diag2.column('position', width=100, anchor="center")
        Job.diag3.column('education', width=100, anchor="center")
        Job.diag4.column('remain', width=50, anchor="center")
        Job.diag4.column('describe', width=100, anchor="center")

        Job.diag1.heading('cid', text='企业注册号')
        Job.diag1.grid(row=4, stick=W, pady=20)

        Job.diag2.heading('cname', text='企业名称')
        Job.diag2.heading('position', text='职位')
        Job.diag2.grid(row=4, stick=W, column=1)

        Job.diag3.heading('education', text='学历要求')
        Job.diag3.grid(row=4, stick=W, column=2)

        Job.diag4.heading('remain', text='剩余量')
        Job.diag4.heading('describe', text='简介')
        Job.diag4.grid(row=4, stick=W, column = 3)
        Label(self.Win, text="申请岗位请输入企业注册号和职位！").grid(row=5, stick=W, column=1)

        self.showAll()


    def showAll(self):
        x = Job.diag1.get_children()
        for item in x:
            Job.diag1.delete(item)
        x = Job.diag2.get_children()
        for item in x:
            Job.diag2.delete(item)
        x = Job.diag3.get_children()
        for item in x:
            Job.diag3.delete(item)
        x = Job.diag4.get_children()
        for item in x:
            Job.diag4.delete(item)
        con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
        cur = con.cursor()
        cur.execute("select * from jobs")
        lst = cur.fetchall()
        # treeview的插入方法
        for item in lst:
            Job.diag1.insert("", 1, text="line1", values=item[0])
            Job.diag2.insert("", 1, text="line1", values=item[1:3])
            Job.diag3.insert("", 1, text="line1", values=item[3])
            Job.diag4.insert("", 1, text="line1", values=item[4:6])
        cur.close()
        con.close()


    def selectJob(self):
        cid=self.cid.get()
        cname='%'+self.cname.get()+'%'
        position='%'+self.position.get()+'%'
        education='%'+self.education.get()+'%'
        if len(cid) == 0 and len(cname) == 2 and len(position) == 2 and len(education) == 2:
            showinfo(title='错误', message='请至少输入一个查询信息！')
        else:
            x = Job.diag1.get_children()
            for item in x:
                Job.diag1.delete(item)
            x = Job.diag2.get_children()
            for item in x:
                Job.diag2.delete(item)
            x = Job.diag3.get_children()
            for item in x:
                Job.diag3.delete(item)
            x = Job.diag4.get_children()
            for item in x:
                Job.diag4.delete(item)
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql = "select * from jobs where "
            lis=[]
            if len(cid)!=0:
                sql +="cid=%s"
                lis.append(cid)
            if len(cname)!=2:
                if sql[-1]=='s':
                    sql+=' and '
                sql+= "name like %s"
                lis.append(cname)
            if len(position)!=2:
                if sql[-1]=='s':
                    sql+=' and '
                sql+="position like %s"
                lis.append(position)
            if len(education)!=2:
                if sql[-1]=='s':
                    sql+=' and '
                sql+="education like %s "
                lis.append(education)
            sql+=" and remain > 0"
            tlis=tuple(lis)
            cur.execute(sql,tlis)
            lst = cur.fetchall()
            print(lst)
            # treeview的插入方法
            for item in lst:
                Job.diag1.insert("", 1, text="line1", values=item[0])
                Job.diag2.insert("", 1, text="line1", values=item[1:3])
                Job.diag3.insert("", 1, text="line1", values=item[3])
                Job.diag4.insert("", 1, text="line1", values=item[4:6])
            cur.close()
            con.close()

    def apply(self):
        cid = self.cid.get()
        position = self.position.get()
        if len(cid)==0 or len(position)==0:
            showinfo(title='错误', message='申请岗位请输入企业注册号和职位！')
        else:
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql = "select * from jobs where cid=%s and position=%s"
            cur.execute(sql, (cid,position))
            lst = cur.fetchone()
            if lst==None:
                showinfo(title='错误', message='无此岗位！')
            else:
                sql = "select * from worker_apply_jobs where id=%s and cid=%s and position=%s"
                cur.execute(sql, (Worker.idnum, cid, position))
                lst = cur.fetchone()
                if lst!=None:
                    print(lst)
                    showinfo(title='提示', message='您已申请此岗位！')
                else:
                    sql = "insert into worker_apply_jobs (id,cid,position) values(%s,%s,%s)"
                    cur.execute(sql, (Worker.idnum, cid, position))
                    con.commit()
                    showinfo(title='提示', message='申请岗位成功！')
            cur.close()
            con.close()
    def goback(self):
        self.Win.destroy()
        Home(self.root)

#企业模式
class Company(object):
    idnum=' '
    def __init__(self, master):
        Login.model=2
        self.root = master  # 定义内部变量root
        self.root.geometry('300x180')  # 设置窗口大小

        self.username = StringVar()
        self.password = StringVar()
        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        Label(self.Win).grid(row=0, stick=W)
        Label(self.Win, text='企业注册号: ').grid(row=1, stick=W, pady=10)
        Entry(self.Win, textvariable=self.username).grid(row=1, column=1, stick=E)
        Label(self.Win, text='密码: ').grid(row=2, stick=W, pady=10)
        Entry(self.Win, textvariable=self.password, show='*').grid(row=2, column=1, stick=E)
        Button(self.Win, text='登陆', command=self.loginCheck).grid(row=3, stick=W, pady=10)
        Button(self.Win, text='注册', command=self.signUp).grid(row=3, stick=W,  column=1)
        Button(self.Win, text='返回', command=self.goback).grid(row=3, column=1, stick=E)

    def loginCheck(self):
        Company.idnum=self.username.get()
        if len(Company.idnum)!=10:
            showinfo(title='错误', message='企业注册号为10位！')
        else:
            password = self.password.get()
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql='select passwd from company where cid = %s'
            cur.execute(sql,Company.idnum)
            result=cur.fetchone()
            if result==None:
                showinfo(title='错误', message='账号错误！')
            elif  password == str(result[0]):
                self.Win.destroy()
                CompanyHome(self.root)
            else:
                showinfo(title='错误', message='密码错误！')
            cur.close()
            con.close()

    def signUp(self):
        self.Win.destroy()
        Sign(self.root)

    def goback(self):
        self.Win.destroy()
        Login(self.root)

#企业首页
class CompanyHome(object):
    def __init__(self, master):
        self.root = master  # 定义内部变量root
        self.root.geometry('300x300')  # 设置窗口大小

        self.username = Company.idnum

        self.createWindow()

    def createWindow(self):
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()
        Label(self.Win).grid(row=0, stick=W)
        Label(self.Win, text="身份证号："+self.username).grid(row=1, stick=W, pady=10)

        Button(self.Win, text='企业信息', command=self.information).grid(row=2, stick=S,  pady=10)
        Button(self.Win, text='岗位信息', command=self.JobEdit).grid(row=3, stick=S, pady=10)
        Button(self.Win, text='人才管理', command=self.WorkerEdit).grid(row=4, stick=S, pady=10)
        Button(self.Win, text='密码设置', command=self.passwd).grid(row=5, stick=S, pady=10)
        Button(self.Win, text='退出登录', command=self.logout).grid(row=6, stick=S, pady=10)


    def information(self):
        print('todo')

    def JobEdit(self):
        self.Win.destroy()
        JobOp(self.root)

    def WorkerEdit(self):
        print('todo')

    def passwd(self):
        self.Win.destroy()
        Password(self.root)

    def logout(self):
        self.Win.destroy()
        Login(self.root)

#岗位管理
class JobOp(object):
    def __init__(self, master):
        self.root = master
        self.root.geometry('600x500')  # 设置窗口大小

        self.cid = Company.idnum
        self.position = StringVar()
        self.education = StringVar()
        self.remain = StringVar()
        self.introduction = StringVar()
        self.createWindow()

    def createWindow(self):
        # self.Win = Frame(self.Win)
        # self.Win = tk.Tk(className="图书管理系统")
        # self.Win.pack()
        self.Win = Frame(self.root)  # 创建Frame
        self.Win.pack()

        Label(self.Win).grid(row=0, stick=W)

        Label(self.Win, text="职位：").grid(row=1, stick=W, pady=10)
        Label(self.Win, text="学历要求：").grid(row=1, stick=W, column=2)
        Label(self.Win, text="需求量：").grid(row=2, stick=W, pady=10)
        Label(self.Win, text="简介：").grid(row=2, stick=W, column=2)

        Entry(self.Win, textvariable=self.position).grid(row=1, stick=W, column=1)
        Entry(self.Win, textvariable=self.education).grid(row=1, stick=W, column=3)
        Entry(self.Win, textvariable=self.remain).grid(row=2, stick=W, column=1)
        Entry(self.Win, textvariable=self.introduction).grid(row=2, stick=W, column=3)
        # 按钮
        Button(self.Win, text="查询岗位", command=self.selectJob).grid(row=3, stick=W, pady=10)
        Button(self.Win, text="添加岗位", command=self.insertJob).grid(row=3,stick=W, column=1)
        Button(self.Win, text="删除岗位", command=self.removeJob).grid(row=3, stick=W, column=2)
        Button(self.Win, text="显示所有岗位", command=self.showAll).grid(row=3, stick=W, column=3)
        Button(self.Win, text="返回", command=self.goback).grid(row=5, stick=W, column=3)

        # 表格
        Job.diag1 = ttk.Treeview(self.Win, show='headings', column=('position'))
        Job.diag2 = ttk.Treeview(self.Win, show='headings', column=('education'))
        Job.diag3 = ttk.Treeview(self.Win, show='headings', column=('remain'))
        Job.diag4 = ttk.Treeview(self.Win, show='headings', column=('describe'))

        Job.diag1.column('position', width=100, anchor="center")
        Job.diag2.column('education', width=200, anchor="center")
        Job.diag3.column('remain', width=100, anchor="center")
        Job.diag4.column('describe', width=150, anchor="center")

        Job.diag1.heading('position', text='职位')
        Job.diag1.grid(row=4, stick=W, pady=20)

        Job.diag2.heading('education', text='学历要求')
        Job.diag2.grid(row=4, stick=W, column=1)

        Job.diag3.heading('remain', text='需求量')
        Job.diag3.grid(row=4, stick=W, column=2)
        Job.diag4.heading('describe', text='简介')
        Job.diag4.grid(row=4, stick=W, column = 3)

        Label(self.Win, text="删除岗位请输入职位！").grid(row=5, stick=W, column=1)
        Button(self.Win, text="批量操作", command=self.largeOp).grid(row=5, stick=W, column=2)

        self.showAll()


    def showAll(self):
        x = Job.diag1.get_children()
        for item in x:
            Job.diag1.delete(item)
        x = Job.diag2.get_children()
        for item in x:
            Job.diag2.delete(item)
        x = Job.diag3.get_children()
        for item in x:
            Job.diag3.delete(item)
        x = Job.diag4.get_children()
        for item in x:
            Job.diag4.delete(item)
        con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
        cur = con.cursor()
        sql="select position,education,remain,introduction from jobs where cid=%s"
        cur.execute(sql,(Company.idnum))
        lst = cur.fetchall()
        # treeview的插入方法
        for item in lst:
            Job.diag1.insert("", 1, text="line1", values=item[0])
            Job.diag2.insert("", 1, text="line1", values=item[1])
            Job.diag3.insert("", 1, text="line1", values=item[2])
            Job.diag4.insert("", 1, text="line1", values=item[3])
        cur.close()
        con.close()


    def selectJob(self):
        position='%'+self.position.get()+'%'
        education='%'+self.education.get()+'%'
        remain = self.remain.get()
        introduction = '%' + self.introduction.get() + '%'
        if len(position) == 2 and len(education) == 2 and len(remain) == 0 and len(introduction)==2:
            showinfo(title='错误', message='请至少输入一个查询信息！')
        else:
            x = Job.diag1.get_children()
            for item in x:
                Job.diag1.delete(item)
            x = Job.diag2.get_children()
            for item in x:
                Job.diag2.delete(item)
            x = Job.diag3.get_children()
            for item in x:
                Job.diag3.delete(item)
            x = Job.diag4.get_children()
            for item in x:
                Job.diag4.delete(item)
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql = "select position,education,remain,introduction from jobs where cid=%s"
            lis=[Company.idnum]

            if len(position)!=2:
                if sql[-1]=='s':
                    sql+=' and '
                sql+="position like %s"
                lis.append(position)
            if len(education)!=2:
                if sql[-1]=='s':
                    sql+=' and '
                sql+="education like %s "
                lis.append(education)
            if len(remain)!=0:
                if sql[-1]=='s':
                    sql+=' and '
                sql+="remain <=%s "
                lis.append(int(remain))
            if len(introduction) != 2:
                if sql[-1] == 's':
                    sql += ' and '
                sql += "introduction like %s "
                lis.append(introduction)
            print(sql)
            tlis=tuple(lis)
            cur.execute(sql,tlis)
            lst = cur.fetchall()
            print(lst)
            # treeview的插入方法
            for item in lst:
                Job.diag1.insert("", 1, text="line1", values=item[0])
                Job.diag2.insert("", 1, text="line1", values=item[1])
                Job.diag3.insert("", 1, text="line1", values=item[2])
                Job.diag4.insert("", 1, text="line1", values=item[3])
            cur.close()
            con.close()

    def insertJob(self):
        position = self.position.get()
        education = self.education.get()
        remain = self.remain.get()
        introduction = self.introduction.get()
        if len(education)==0 or len(position)==0 or len(remain)==0:
            showinfo(title='错误', message='请至少输入除简介外的所有信息！')
        else:
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql = "select * from jobs where cid=%s and position=%s"
            cur.execute(sql, (Company.idnum,position))
            lst = cur.fetchone()
            if lst!=None:
                showinfo(title='错误', message='此岗位已存在！')
            else:
                cur.execute("select name from company where cid =%s",(Company.idnum))
                lst1 = cur.fetchone()
                sql = "insert into jobs (cid,name,position,education,remain,introduction) values(%s,%s,%s,%s,%s,%s)"
                cur.execute(sql, (Company.idnum, lst1,position,education,int(remain),introduction))
                con.commit()
                showinfo(title='提示', message='添加岗位成功！')
                self.showAll()
            cur.close()
            con.close()

    def removeJob(self):
        position = self.position.get()
        if len(position)==0:
            showinfo(title='错误', message='请输入职位！')
        else:
            con = pymysql.connect(user='root', password='123456', database='jobs', charset='utf8')
            cur = con.cursor()
            sql = "select * from jobs where cid=%s and position=%s"
            cur.execute(sql, (Company.idnum, position))
            lst = cur.fetchone()
            if lst == None:
                showinfo(title='错误', message='此岗位不存在！')
            else:

                sql = "delete from jobs where cid=%s and position=%s"
                cur.execute(sql, (Company.idnum, position,))
                con.commit()
                showinfo(title='提示', message='删除岗位成功！')
                self.showAll()
            cur.close()
            con.close()
    def largeOp(self):
        print("todo")
    def goback(self):
        self.Win.destroy()
        Home(self.root)